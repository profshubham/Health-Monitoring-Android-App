package com.hmon.app.modules.sostwo.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseDialogFragment
import com.hmon.app.databinding.DialogSosTwoBinding
import com.hmon.app.modules.sostwo.`data`.viewmodel.SosTwoVM
import kotlin.String
import kotlin.Unit

class SosTwoDialog : BaseDialogFragment<DialogSosTwoBinding>(R.layout.dialog_sos_two) {
  private val viewModel: SosTwoVM by viewModels<SosTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.sosTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnCancel.setOnClickListener {
      dismiss()
    }
  }

  companion object {
    const val TAG: String = "SOS_TWO_DIALOG"

  }
}
