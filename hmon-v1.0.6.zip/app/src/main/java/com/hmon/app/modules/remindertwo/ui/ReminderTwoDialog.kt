package com.hmon.app.modules.remindertwo.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseDialogFragment
import com.hmon.app.databinding.DialogReminderTwoBinding
import com.hmon.app.modules.remindertwo.`data`.viewmodel.ReminderTwoVM
import kotlin.String
import kotlin.Unit

class ReminderTwoDialog : BaseDialogFragment<DialogReminderTwoBinding>(R.layout.dialog_reminder_two)
    {
  private val viewModel: ReminderTwoVM by viewModels<ReminderTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.reminderTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnCancel.setOnClickListener {
      dismiss()
    }
  }

  companion object {
    const val TAG: String = "REMINDER_TWO_DIALOG"

  }
}
