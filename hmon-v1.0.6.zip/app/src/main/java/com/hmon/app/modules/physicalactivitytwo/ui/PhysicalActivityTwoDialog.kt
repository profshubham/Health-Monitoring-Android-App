package com.hmon.app.modules.physicalactivitytwo.ui

import android.content.Context
import androidx.fragment.app.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseDialogFragment
import com.hmon.app.databinding.DialogPhysicalActivityTwoBinding
import com.hmon.app.modules.physicalactivitytwo.`data`.viewmodel.PhysicalActivityTwoVM
import kotlin.String
import kotlin.Unit

class PhysicalActivityTwoDialog :
    BaseDialogFragment<DialogPhysicalActivityTwoBinding>(R.layout.dialog_physical_activity_two) {
  private val viewModel: PhysicalActivityTwoVM by viewModels<PhysicalActivityTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = arguments
    binding.physicalActivityTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.btnCancel.setOnClickListener {
      dismiss()
    }
  }

  companion object {
    const val TAG: String = "PHYSICAL_ACTIVITY_TWO_DIALOG"

  }
}
