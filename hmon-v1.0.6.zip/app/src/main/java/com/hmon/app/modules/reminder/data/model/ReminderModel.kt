package com.hmon.app.modules.reminder.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class ReminderModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtReminder: String? = MyApp.getInstance().resources.getString(R.string.lbl_reminder)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGoodMorningGr: String? =
      MyApp.getInstance().resources.getString(R.string.msg_good_morning_g)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGoodMorningGrOne: String? =
      MyApp.getInstance().resources.getString(R.string.msg_good_morning_g)

)
