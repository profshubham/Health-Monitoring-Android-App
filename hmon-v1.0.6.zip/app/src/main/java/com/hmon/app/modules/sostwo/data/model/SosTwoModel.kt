package com.hmon.app.modules.sostwo.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class SosTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddEmergencyC: String? =
      MyApp.getInstance().resources.getString(R.string.msg_add_emergency_c)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtName: String? = MyApp.getInstance().resources.getString(R.string.lbl_name)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtRelation: String? = MyApp.getInstance().resources.getString(R.string.lbl_relation)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumber: String? = MyApp.getInstance().resources.getString(R.string.lbl_number)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtMessage: String? = MyApp.getInstance().resources.getString(R.string.lbl_message)

)
