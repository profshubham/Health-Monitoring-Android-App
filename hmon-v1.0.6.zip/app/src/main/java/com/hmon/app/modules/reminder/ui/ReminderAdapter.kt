package com.hmon.app.modules.reminder.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hmon.app.R
import com.hmon.app.databinding.RowReminderBinding
import com.hmon.app.modules.reminder.`data`.model.ReminderRowModel
import kotlin.Int
import kotlin.collections.List

class ReminderAdapter(
  var list: List<ReminderRowModel>
) : RecyclerView.Adapter<ReminderAdapter.RowReminderVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowReminderVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_reminder,parent,false)
    return RowReminderVH(view)
  }

  override fun onBindViewHolder(holder: RowReminderVH, position: Int) {
    val reminderRowModel = ReminderRowModel()
    // TODO uncomment following line after integration with data source
    // val reminderRowModel = list[position]
    holder.binding.reminderRowModel = reminderRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ReminderRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ReminderRowModel
    ) {
    }
  }

  inner class RowReminderVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowReminderBinding = RowReminderBinding.bind(itemView)
  }
}
