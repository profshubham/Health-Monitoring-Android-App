package com.hmon.app.modules.logout.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class LogOutModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtLoggedoutSucc: String? =
      MyApp.getInstance().resources.getString(R.string.msg_logged_out_succ)

)
