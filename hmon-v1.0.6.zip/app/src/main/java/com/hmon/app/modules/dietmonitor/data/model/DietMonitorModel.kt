package com.hmon.app.modules.dietmonitor.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class DietMonitorModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtDietMonitor: String? = MyApp.getInstance().resources.getString(R.string.lbl_diet_monitor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWaterIntake: String? = MyApp.getInstance().resources.getString(R.string.lbl_water_intake)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTwelve: String? = MyApp.getInstance().resources.getString(R.string.lbl2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPastRecords: String? = MyApp.getInstance().resources.getString(R.string.lbl_past_records)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCalories: String? = MyApp.getInstance().resources.getString(R.string.lbl_calories)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtThirteen: String? = MyApp.getInstance().resources.getString(R.string.lbl2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPastRecordsOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_past_records)

)
