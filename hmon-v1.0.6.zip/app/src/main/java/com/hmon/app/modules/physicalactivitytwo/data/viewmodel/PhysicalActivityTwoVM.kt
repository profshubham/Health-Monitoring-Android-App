package com.hmon.app.modules.physicalactivitytwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.physicalactivitytwo.`data`.model.PhysicalActivityTwoModel
import org.koin.core.KoinComponent

class PhysicalActivityTwoVM : ViewModel(), KoinComponent {
  val physicalActivityTwoModel: MutableLiveData<PhysicalActivityTwoModel> =
      MutableLiveData(PhysicalActivityTwoModel())

  var navArguments: Bundle? = null
}
