package com.hmon.app.modules.reminder.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class ReminderRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_8_00_am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_8_00_am)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAcetaminophen: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_acetaminophen)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAcetaminophenOne: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_acetaminophen)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPillCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_pill)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPillCounterOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_1_pill)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBeforeFood: String? = MyApp.getInstance().resources.getString(R.string.lbl_before_food)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBeforeFoodOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_before_food)

)
