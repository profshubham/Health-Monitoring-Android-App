package com.hmon.app.modules.dietmonitortwo.ui

import android.view.View
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityDietMonitorTwoBinding
import com.hmon.app.modules.dietmonitortwo.`data`.model.ListfourteenRowModel
import com.hmon.app.modules.dietmonitortwo.`data`.model.ListsixteenRowModel
import com.hmon.app.modules.dietmonitortwo.`data`.model.SpinnerGroup1116Model
import com.hmon.app.modules.dietmonitortwo.`data`.viewmodel.DietMonitorTwoVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class DietMonitorTwoActivity :
    BaseActivity<ActivityDietMonitorTwoBinding>(R.layout.activity_diet_monitor_two) {
  private val viewModel: DietMonitorTwoVM by viewModels<DietMonitorTwoVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    viewModel.spinnerGroup1116List.value = mutableListOf(
    SpinnerGroup1116Model("Item1"),
    SpinnerGroup1116Model("Item2"),
    SpinnerGroup1116Model("Item3"),
    SpinnerGroup1116Model("Item4"),
    SpinnerGroup1116Model("Item5")
    )
    val spinnerGroup1116Adapter =
    SpinnerGroup1116Adapter(this,R.layout.spinner_item,viewModel.spinnerGroup1116List.value?:
    mutableListOf())
    binding.spinnerGroup1116.adapter = spinnerGroup1116Adapter
    val listfourteenAdapter =
    ListfourteenAdapter(viewModel.listfourteenList.value?:mutableListOf())
    binding.recyclerListfourteen.adapter = listfourteenAdapter
    listfourteenAdapter.setOnItemClickListener(
    object : ListfourteenAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListfourteenRowModel) {
        onClickRecyclerListfourteen(view, position, item)
      }
    }
    )
    viewModel.listfourteenList.observe(this) {
      listfourteenAdapter.updateData(it)
    }
    val listsixteenAdapter =
    ListsixteenAdapter(viewModel.listsixteenList.value?:mutableListOf())
    binding.recyclerListsixteen.adapter = listsixteenAdapter
    listsixteenAdapter.setOnItemClickListener(
    object : ListsixteenAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListsixteenRowModel) {
        onClickRecyclerListsixteen(view, position, item)
      }
    }
    )
    viewModel.listsixteenList.observe(this) {
      listsixteenAdapter.updateData(it)
    }
    binding.dietMonitorTwoVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListfourteen(
    view: View,
    position: Int,
    item: ListfourteenRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListsixteen(
    view: View,
    position: Int,
    item: ListsixteenRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "DIET_MONITOR_TWO_ACTIVITY"

  }
}
