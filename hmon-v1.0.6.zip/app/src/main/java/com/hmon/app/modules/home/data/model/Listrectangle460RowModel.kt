package com.hmon.app.modules.home.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class Listrectangle460RowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtThe25Healthie: String? =
      MyApp.getInstance().resources.getString(R.string.msg_the_25_healthie)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLanguage: String? = MyApp.getInstance().resources.getString(R.string.lbl_jun_10_2021)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_5min_read)

)
