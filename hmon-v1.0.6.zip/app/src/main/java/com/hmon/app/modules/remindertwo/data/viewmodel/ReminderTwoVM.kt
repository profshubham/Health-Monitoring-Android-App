package com.hmon.app.modules.remindertwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.remindertwo.`data`.model.ReminderTwoModel
import org.koin.core.KoinComponent

class ReminderTwoVM : ViewModel(), KoinComponent {
  val reminderTwoModel: MutableLiveData<ReminderTwoModel> = MutableLiveData(ReminderTwoModel())

  var navArguments: Bundle? = null
}
