package com.hmon.app.modules.sos.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivitySosBinding
import com.hmon.app.modules.sos.`data`.viewmodel.SosVM
import kotlin.String
import kotlin.Unit

class SosActivity : BaseActivity<ActivitySosBinding>(R.layout.activity_sos) {
  private val viewModel: SosVM by viewModels<SosVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.sosVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  companion object {
    const val TAG: String = "SOS_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, SosActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
