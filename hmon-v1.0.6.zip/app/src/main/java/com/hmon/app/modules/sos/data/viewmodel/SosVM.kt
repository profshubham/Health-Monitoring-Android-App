package com.hmon.app.modules.sos.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.sos.`data`.model.SosModel
import org.koin.core.KoinComponent

class SosVM : ViewModel(), KoinComponent {
  val sosModel: MutableLiveData<SosModel> = MutableLiveData(SosModel())

  var navArguments: Bundle? = null
}
