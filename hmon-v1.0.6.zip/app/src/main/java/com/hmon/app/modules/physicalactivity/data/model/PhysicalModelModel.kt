package com.hmon.app.modules.physicalactivity.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class PhysicalModelModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtActivityTracke: String? =
      MyApp.getInstance().resources.getString(R.string.msg_activity_tracke)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOctoberCounter: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_october_2023)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDay: String? = MyApp.getInstance().resources.getString(R.string.lbl_m)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumber: String? = MyApp.getInstance().resources.getString(R.string.lbl_16)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDayOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_t)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumberOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_17)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDayTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_w)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumberTwo: String? = MyApp.getInstance().resources.getString(R.string.lbl_18)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDayThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_t)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumberThree: String? = MyApp.getInstance().resources.getString(R.string.lbl_19)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDayFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_f)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumberFour: String? = MyApp.getInstance().resources.getString(R.string.lbl_20)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDayFive: String? = MyApp.getInstance().resources.getString(R.string.lbl_s)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumberFive: String? = MyApp.getInstance().resources.getString(R.string.lbl_21)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDaySix: String? = MyApp.getInstance().resources.getString(R.string.lbl_s)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtNumberSix: String? = MyApp.getInstance().resources.getString(R.string.lbl_22)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSevenHundredFortyFive: String? = MyApp.getInstance().resources.getString(R.string.lbl_745)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtCal: String? = MyApp.getInstance().resources.getString(R.string.lbl_cal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSubtitle: String? = MyApp.getInstance().resources.getString(R.string.lbl_active_calories)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWorkFinish: String? = MyApp.getInstance().resources.getString(R.string.lbl_work_finish)

)
