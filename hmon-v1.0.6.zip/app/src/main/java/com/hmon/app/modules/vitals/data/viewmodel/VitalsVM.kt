package com.hmon.app.modules.vitals.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.vitals.`data`.model.VitalsModel
import com.hmon.app.modules.vitals.`data`.model.VitalsRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class VitalsVM : ViewModel(), KoinComponent {
  val vitalsModel: MutableLiveData<VitalsModel> = MutableLiveData(VitalsModel())

  var navArguments: Bundle? = null

  val vitalsList: MutableLiveData<MutableList<VitalsRowModel>> = MutableLiveData(mutableListOf())
}
