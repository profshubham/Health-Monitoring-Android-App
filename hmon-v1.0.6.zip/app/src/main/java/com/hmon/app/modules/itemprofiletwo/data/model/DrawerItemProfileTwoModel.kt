package com.hmon.app.modules.itemprofiletwo.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class DrawerItemProfileTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtChangeProfile: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_change_profile)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLogIn: String? = MyApp.getInstance().resources.getString(R.string.lbl_log_in2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtListalltheal: String? =
      MyApp.getInstance().resources.getString(R.string.msg_list_all_the_al)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAllergens: String? = MyApp.getInstance().resources.getString(R.string.lbl_allergens)

)
