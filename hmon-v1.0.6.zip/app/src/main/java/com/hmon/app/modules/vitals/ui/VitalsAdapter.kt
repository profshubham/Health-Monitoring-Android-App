package com.hmon.app.modules.vitals.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hmon.app.R
import com.hmon.app.databinding.RowVitalsBinding
import com.hmon.app.modules.vitals.`data`.model.VitalsRowModel
import kotlin.Int
import kotlin.collections.List

class VitalsAdapter(
  var list: List<VitalsRowModel>
) : RecyclerView.Adapter<VitalsAdapter.RowVitalsVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowVitalsVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_vitals,parent,false)
    return RowVitalsVH(view)
  }

  override fun onBindViewHolder(holder: RowVitalsVH, position: Int) {
    val vitalsRowModel = VitalsRowModel()
    // TODO uncomment following line after integration with data source
    // val vitalsRowModel = list[position]
    holder.binding.vitalsRowModel = vitalsRowModel
  }

  override fun getItemCount(): Int = 7
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<VitalsRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: VitalsRowModel
    ) {
    }
  }

  inner class RowVitalsVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowVitalsBinding = RowVitalsBinding.bind(itemView)
  }
}
