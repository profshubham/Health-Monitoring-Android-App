package com.hmon.app.modules.dietmonitor.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class ListtenRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtTen: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtKcalCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_320_kcal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt091223Two: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_12_23)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAfternoon: String? = MyApp.getInstance().resources.getString(R.string.lbl_afternoon)

)
