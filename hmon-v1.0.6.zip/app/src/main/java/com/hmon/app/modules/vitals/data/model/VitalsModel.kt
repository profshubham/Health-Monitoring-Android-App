package com.hmon.app.modules.vitals.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class VitalsModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtVitals: String? = MyApp.getInstance().resources.getString(R.string.lbl_vitals)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPulse: String? = MyApp.getInstance().resources.getString(R.string.lbl_pulse)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeventyEight: String? = MyApp.getInstance().resources.getString(R.string.lbl_78)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBpm: String? = MyApp.getInstance().resources.getString(R.string.lbl_bpm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPastRecords: String? = MyApp.getInstance().resources.getString(R.string.lbl_past_records)

)
