package com.hmon.app.modules.dietmonitor.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityDietMonitorBinding
import com.hmon.app.modules.dietmonitor.`data`.model.ListeightRowModel
import com.hmon.app.modules.dietmonitor.`data`.model.ListtenRowModel
import com.hmon.app.modules.dietmonitor.`data`.viewmodel.DietMonitorVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class DietMonitorActivity : BaseActivity<ActivityDietMonitorBinding>(R.layout.activity_diet_monitor)
    {
  private val viewModel: DietMonitorVM by viewModels<DietMonitorVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val listeightAdapter = ListeightAdapter(viewModel.listeightList.value?:mutableListOf())
    binding.recyclerListeight.adapter = listeightAdapter
    listeightAdapter.setOnItemClickListener(
    object : ListeightAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListeightRowModel) {
        onClickRecyclerListeight(view, position, item)
      }
    }
    )
    viewModel.listeightList.observe(this) {
      listeightAdapter.updateData(it)
    }
    val listtenAdapter = ListtenAdapter(viewModel.listtenList.value?:mutableListOf())
    binding.recyclerListten.adapter = listtenAdapter
    listtenAdapter.setOnItemClickListener(
    object : ListtenAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListtenRowModel) {
        onClickRecyclerListten(view, position, item)
      }
    }
    )
    viewModel.listtenList.observe(this) {
      listtenAdapter.updateData(it)
    }
    binding.dietMonitorVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerListeight(
    view: View,
    position: Int,
    item: ListeightRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListten(
    view: View,
    position: Int,
    item: ListtenRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "DIET_MONITOR_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, DietMonitorActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
