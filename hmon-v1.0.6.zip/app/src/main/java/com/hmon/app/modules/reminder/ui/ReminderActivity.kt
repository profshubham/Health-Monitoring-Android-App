package com.hmon.app.modules.reminder.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityReminderBinding
import com.hmon.app.modules.reminder.`data`.model.ReminderRowModel
import com.hmon.app.modules.reminder.`data`.viewmodel.ReminderVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class ReminderActivity : BaseActivity<ActivityReminderBinding>(R.layout.activity_reminder) {
  private val viewModel: ReminderVM by viewModels<ReminderVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val reminderAdapter = ReminderAdapter(viewModel.reminderList.value?:mutableListOf())
    binding.recyclerReminder.adapter = reminderAdapter
    reminderAdapter.setOnItemClickListener(
    object : ReminderAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ReminderRowModel) {
        onClickRecyclerReminder(view, position, item)
      }
    }
    )
    viewModel.reminderList.observe(this) {
      reminderAdapter.updateData(it)
    }
    binding.reminderVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerReminder(
    view: View,
    position: Int,
    item: ReminderRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "REMINDER_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, ReminderActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
