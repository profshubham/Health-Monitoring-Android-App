package com.hmon.app.modules.logout.ui

import android.os.Handler
import android.os.Looper
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityLogOutBinding
import com.hmon.app.modules.loginscreen.ui.LoginScreenActivity
import com.hmon.app.modules.logout.`data`.viewmodel.LogOutVM
import kotlin.String
import kotlin.Unit

class LogOutActivity : BaseActivity<ActivityLogOutBinding>(R.layout.activity_log_out) {
  private val viewModel: LogOutVM by viewModels<LogOutVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.logOutVM = viewModel
    Handler(Looper.getMainLooper()).postDelayed( {
      val destIntent = LoginScreenActivity.getIntent(this, null)
      startActivity(destIntent)
      finish()
      }, 3000)
    }

    override fun setUpClicks(): Unit {
    }

    companion object {
      const val TAG: String = "LOG_OUT_ACTIVITY"

    }
  }
