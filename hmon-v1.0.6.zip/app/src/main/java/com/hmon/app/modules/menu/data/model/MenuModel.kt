package com.hmon.app.modules.menu.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class MenuModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup1169: String? = MyApp.getInstance().resources.getString(R.string.lbl_reminder)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup1171: String? = MyApp.getInstance().resources.getString(R.string.lbl_vitals)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup1173: String? = MyApp.getInstance().resources.getString(R.string.lbl_diet_monitor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_sos)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtGroup1177: String? = MyApp.getInstance().resources.getString(R.string.lbl_appointment)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPhysicalActivi: String? =
      MyApp.getInstance().resources.getString(R.string.msg_physical_activi)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtLogout: String? = MyApp.getInstance().resources.getString(R.string.lbl_logout)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1167Value: String? = null
)
