package com.hmon.app.modules.physicalactivitytwo.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class PhysicalActivityTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddActivity: String? = MyApp.getInstance().resources.getString(R.string.lbl_add_activity)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAdd: String? = MyApp.getInstance().resources.getString(R.string.lbl_add)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtWalking: String? = MyApp.getInstance().resources.getString(R.string.lbl_walking)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_12_07_pm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTimeOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_30_min)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddkm: String? = MyApp.getInstance().resources.getString(R.string.lbl_add_km)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddCal: String? = MyApp.getInstance().resources.getString(R.string.lbl_add_cal)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtAddsteps: String? = MyApp.getInstance().resources.getString(R.string.lbl_add_steps)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1181Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1185Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1189Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1193Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1197Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1201Value: String? = null,
  /**
   * TODO Replace with dynamic value
   */
  var etGroup1205Value: String? = null
)
