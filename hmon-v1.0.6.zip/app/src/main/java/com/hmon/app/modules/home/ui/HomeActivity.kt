package com.hmon.app.modules.home.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import androidx.core.view.GravityCompat
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityHomeBinding
import com.hmon.app.modules.home.`data`.model.DoctorRowModel
import com.hmon.app.modules.home.`data`.model.Listrectangle460RowModel
import com.hmon.app.modules.home.`data`.viewmodel.HomeVM
import kotlin.Boolean
import kotlin.Int
import kotlin.String
import kotlin.Unit

class HomeActivity : BaseActivity<ActivityHomeBinding>(R.layout.activity_home) {
  private val viewModel: HomeVM by viewModels<HomeVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val doctorAdapter = DoctorAdapter(viewModel.doctorList.value?:mutableListOf())
    binding.recyclerDoctor.adapter = doctorAdapter
    doctorAdapter.setOnItemClickListener(
    object : DoctorAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : DoctorRowModel) {
        onClickRecyclerDoctor(view, position, item)
      }
    }
    )
    viewModel.doctorList.observe(this) {
      doctorAdapter.updateData(it)
    }
    val listrectangle460Adapter =
    Listrectangle460Adapter(viewModel.listrectangle460List.value?:mutableListOf())
    binding.recyclerListrectangle460.adapter = listrectangle460Adapter
    listrectangle460Adapter.setOnItemClickListener(
    object : Listrectangle460Adapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : Listrectangle460RowModel) {
        onClickRecyclerListrectangle460(view, position, item)
      }
    }
    )
    viewModel.listrectangle460List.observe(this) {
      listrectangle460Adapter.updateData(it)
    }
    binding.homeVM = viewModel
    setUpSearchViewSearchListener()
  }

  override fun setUpClicks(): Unit {
    binding.imageMenu.setOnClickListener {
      	toggleDrawer()
    }
  }

  private fun toggleDrawer(): Unit {
    if (!binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
      binding.drawerLayout.openDrawer(GravityCompat.START)
    }
    else {
      binding.drawerLayout.closeDrawer(GravityCompat.START)
    }
  }

  fun onClickRecyclerDoctor(
    view: View,
    position: Int,
    item: DoctorRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListrectangle460(
    view: View,
    position: Int,
    item: Listrectangle460RowModel
  ): Unit {
    when(view.id) {
    }
  }

  private fun setUpSearchViewSearchListener(): Unit {
    binding.searchViewSearch.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
      override fun onQueryTextSubmit(p0 : String) : Boolean {
        // Performs search when user hit
        // the search button on the keyboard
        return false
      }
      override fun onQueryTextChange(p0 : String) : Boolean {
        // Start filtering the list as user
        // start entering the characters
        return false
      }
      })
    }

    companion object {
      const val TAG: String = "HOME_ACTIVITY"


      fun getIntent(context: Context, bundle: Bundle?): Intent {
        val destIntent = Intent(context, HomeActivity::class.java)
        destIntent.putExtra("bundle", bundle)
        return destIntent
      }
    }
  }
