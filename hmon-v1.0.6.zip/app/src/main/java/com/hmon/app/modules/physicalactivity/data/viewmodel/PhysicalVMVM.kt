package com.hmon.app.modules.physicalactivity.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.physicalactivity.`data`.model.ListnameRowModel
import com.hmon.app.modules.physicalactivity.`data`.model.PhysicalModelModel
import com.hmon.app.modules.physicalactivity.`data`.model.StaggeredellipsethirtyoneRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class PhysicalVMVM : ViewModel(), KoinComponent {
  val physicalModelModel: MutableLiveData<PhysicalModelModel> =
      MutableLiveData(PhysicalModelModel())

  var navArguments: Bundle? = null

  val staggeredellipsethirtyoneList: MutableLiveData<MutableList<StaggeredellipsethirtyoneRowModel>>
      = MutableLiveData(mutableListOf())

  val listnameList: MutableLiveData<MutableList<ListnameRowModel>> =
      MutableLiveData(mutableListOf())
}
