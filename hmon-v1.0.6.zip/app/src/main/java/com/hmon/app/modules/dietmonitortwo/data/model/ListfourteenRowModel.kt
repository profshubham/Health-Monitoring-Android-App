package com.hmon.app.modules.dietmonitortwo.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class ListfourteenRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtFourteen: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtOzCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_0_5_oz)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt091223: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_12_23)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_51_pm)

)
