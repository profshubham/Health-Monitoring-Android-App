package com.hmon.app.modules.vitals.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class VitalsRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtOne: String? = MyApp.getInstance().resources.getString(R.string.lbl)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtBpmCounter: String? = MyApp.getInstance().resources.getString(R.string.lbl_77_bpm)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txt091223: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_12_23)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_09_51_pm)

)
