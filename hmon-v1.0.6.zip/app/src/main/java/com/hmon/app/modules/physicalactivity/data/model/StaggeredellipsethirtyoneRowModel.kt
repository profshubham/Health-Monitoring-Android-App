package com.hmon.app.modules.physicalactivity.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class StaggeredellipsethirtyoneRowModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtSubtitleOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_steps)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtZipcode: String? = MyApp.getInstance().resources.getString(R.string.lbl_6540)

)
