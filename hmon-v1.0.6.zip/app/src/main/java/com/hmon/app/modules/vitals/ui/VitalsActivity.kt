package com.hmon.app.modules.vitals.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityVitalsBinding
import com.hmon.app.modules.vitals.`data`.model.VitalsRowModel
import com.hmon.app.modules.vitals.`data`.viewmodel.VitalsVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class VitalsActivity : BaseActivity<ActivityVitalsBinding>(R.layout.activity_vitals) {
  private val viewModel: VitalsVM by viewModels<VitalsVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val vitalsAdapter = VitalsAdapter(viewModel.vitalsList.value?:mutableListOf())
    binding.recyclerVitals.adapter = vitalsAdapter
    vitalsAdapter.setOnItemClickListener(
    object : VitalsAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : VitalsRowModel) {
        onClickRecyclerVitals(view, position, item)
      }
    }
    )
    viewModel.vitalsList.observe(this) {
      vitalsAdapter.updateData(it)
    }
    binding.vitalsVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerVitals(
    view: View,
    position: Int,
    item: VitalsRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "VITALS_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, VitalsActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
