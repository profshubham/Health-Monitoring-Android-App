package com.hmon.app.modules.dietmonitortwo.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hmon.app.R
import com.hmon.app.databinding.RowListsixteenBinding
import com.hmon.app.modules.dietmonitortwo.`data`.model.ListsixteenRowModel
import kotlin.Int
import kotlin.collections.List

class ListsixteenAdapter(
  var list: List<ListsixteenRowModel>
) : RecyclerView.Adapter<ListsixteenAdapter.RowListsixteenVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListsixteenVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listsixteen,parent,false)
    return RowListsixteenVH(view)
  }

  override fun onBindViewHolder(holder: RowListsixteenVH, position: Int) {
    val listsixteenRowModel = ListsixteenRowModel()
    // TODO uncomment following line after integration with data source
    // val listsixteenRowModel = list[position]
    holder.binding.listsixteenRowModel = listsixteenRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListsixteenRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListsixteenRowModel
    ) {
    }
  }

  inner class RowListsixteenVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListsixteenBinding = RowListsixteenBinding.bind(itemView)
  }
}
