package com.hmon.app.modules.dietmonitortwo.`data`.model

import kotlin.String

data class SpinnerGroup1116Model(
  val itemName: String
)
