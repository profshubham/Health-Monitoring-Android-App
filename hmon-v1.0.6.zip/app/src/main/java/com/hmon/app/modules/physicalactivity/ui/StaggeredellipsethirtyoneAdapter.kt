package com.hmon.app.modules.physicalactivity.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hmon.app.R
import com.hmon.app.databinding.RowStaggeredellipsethirtyoneBinding
import com.hmon.app.modules.physicalactivity.`data`.model.StaggeredellipsethirtyoneRowModel
import kotlin.Int
import kotlin.collections.List

class StaggeredellipsethirtyoneAdapter(
  var list: List<StaggeredellipsethirtyoneRowModel>
) : RecyclerView.Adapter<StaggeredellipsethirtyoneAdapter.RowStaggeredellipsethirtyoneVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int):
      RowStaggeredellipsethirtyoneVH {
    val
        view=LayoutInflater.from(parent.context).inflate(R.layout.row_staggeredellipsethirtyone,parent,false)
    return RowStaggeredellipsethirtyoneVH(view)
  }

  override fun onBindViewHolder(holder: RowStaggeredellipsethirtyoneVH, position: Int) {
    val staggeredellipsethirtyoneRowModel = StaggeredellipsethirtyoneRowModel()
    // TODO uncomment following line after integration with data source
    // val staggeredellipsethirtyoneRowModel = list[position]
    holder.binding.staggeredellipsethirtyoneRowModel = staggeredellipsethirtyoneRowModel
  }

  override fun getItemCount(): Int = 3
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<StaggeredellipsethirtyoneRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: StaggeredellipsethirtyoneRowModel
    ) {
    }
  }

  inner class RowStaggeredellipsethirtyoneVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowStaggeredellipsethirtyoneBinding =
        RowStaggeredellipsethirtyoneBinding.bind(itemView)
  }
}
