package com.hmon.app.modules.logout.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.logout.`data`.model.LogOutModel
import org.koin.core.KoinComponent

class LogOutVM : ViewModel(), KoinComponent {
  val logOutModel: MutableLiveData<LogOutModel> = MutableLiveData(LogOutModel())

  var navArguments: Bundle? = null
}
