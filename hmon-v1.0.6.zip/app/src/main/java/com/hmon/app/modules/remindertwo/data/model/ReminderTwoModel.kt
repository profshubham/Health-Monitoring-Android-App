package com.hmon.app.modules.remindertwo.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class ReminderTwoModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtAddReminder: String? = MyApp.getInstance().resources.getString(R.string.lbl_add_reminder)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtName: String? = MyApp.getInstance().resources.getString(R.string.lbl_name)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtTime: String? = MyApp.getInstance().resources.getString(R.string.lbl_time)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDose: String? = MyApp.getInstance().resources.getString(R.string.lbl_dose)

)
