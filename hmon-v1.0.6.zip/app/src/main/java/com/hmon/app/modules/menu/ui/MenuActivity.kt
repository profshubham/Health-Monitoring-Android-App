package com.hmon.app.modules.menu.ui

import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityMenuBinding
import com.hmon.app.modules.dietmonitor.ui.DietMonitorActivity
import com.hmon.app.modules.menu.`data`.viewmodel.MenuVM
import com.hmon.app.modules.physicalactivity.ui.PhysicalActivityActivity
import com.hmon.app.modules.reminder.ui.ReminderActivity
import com.hmon.app.modules.sos.ui.SosActivity
import com.hmon.app.modules.splash.ui.SplashActivity
import com.hmon.app.modules.vitals.ui.VitalsActivity
import kotlin.Int
import kotlin.String
import kotlin.Unit

class MenuActivity : BaseActivity<ActivityMenuBinding>(R.layout.activity_menu) {
  private val viewModel: MenuVM by viewModels<MenuVM>()

  private val REQUEST_CODE_SPLASH_ACTIVITY: Int = 980

  private val REQUEST_CODE_PHYSICAL_ACTIVITY_ACTIVITY: Int = 939

  private val REQUEST_CODE_REMINDER_ACTIVITY: Int = 966

  private val REQUEST_CODE_SOS_ACTIVITY: Int = 838

  private val REQUEST_CODE_DIET_MONITOR_ACTIVITY: Int = 873

  private val REQUEST_CODE_VITALS_ACTIVITY: Int = 852

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    binding.menuVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.txtLogout.setOnClickListener {
      val destIntent = SplashActivity.getIntent(this, null)
      startActivityForResult(destIntent, REQUEST_CODE_SPLASH_ACTIVITY)
    }
    binding.txtPhysicalActivi.setOnClickListener {
      val destIntent = PhysicalActivityActivity.getIntent(this, null)
      startActivityForResult(destIntent, REQUEST_CODE_PHYSICAL_ACTIVITY_ACTIVITY)
    }
    binding.txtGroup1169.setOnClickListener {
      val destIntent = ReminderActivity.getIntent(this, null)
      startActivityForResult(destIntent, REQUEST_CODE_REMINDER_ACTIVITY)
    }
    binding.txtPrice.setOnClickListener {
      val destIntent = SosActivity.getIntent(this, null)
      startActivityForResult(destIntent, REQUEST_CODE_SOS_ACTIVITY)
    }
    binding.txtGroup1173.setOnClickListener {
      val destIntent = DietMonitorActivity.getIntent(this, null)
      startActivityForResult(destIntent, REQUEST_CODE_DIET_MONITOR_ACTIVITY)
    }
    binding.txtGroup1171.setOnClickListener {
      val destIntent = VitalsActivity.getIntent(this, null)
      startActivityForResult(destIntent, REQUEST_CODE_VITALS_ACTIVITY)
    }
  }

  companion object {
    const val TAG: String = "MENU_ACTIVITY"

  }
}
