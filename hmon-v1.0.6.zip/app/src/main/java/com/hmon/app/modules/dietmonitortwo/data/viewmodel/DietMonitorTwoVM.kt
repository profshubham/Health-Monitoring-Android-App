package com.hmon.app.modules.dietmonitortwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.dietmonitortwo.`data`.model.DietMonitorTwoModel
import com.hmon.app.modules.dietmonitortwo.`data`.model.ListfourteenRowModel
import com.hmon.app.modules.dietmonitortwo.`data`.model.ListsixteenRowModel
import com.hmon.app.modules.dietmonitortwo.`data`.model.SpinnerGroup1116Model
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class DietMonitorTwoVM : ViewModel(), KoinComponent {
  val dietMonitorTwoModel: MutableLiveData<DietMonitorTwoModel> =
      MutableLiveData(DietMonitorTwoModel())

  var navArguments: Bundle? = null

  val spinnerGroup1116List: MutableLiveData<MutableList<SpinnerGroup1116Model>> = MutableLiveData()

  val listfourteenList: MutableLiveData<MutableList<ListfourteenRowModel>> =
      MutableLiveData(mutableListOf())

  val listsixteenList: MutableLiveData<MutableList<ListsixteenRowModel>> =
      MutableLiveData(mutableListOf())
}
