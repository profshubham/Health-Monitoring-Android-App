package com.hmon.app.modules.home.`data`.model

import com.hmon.app.R
import com.hmon.app.appcomponents.di.MyApp
import kotlin.String

data class HomeModel(
  /**
   * TODO Replace with dynamic value
   */
  var txtGoodMorning: String? = MyApp.getInstance().resources.getString(R.string.lbl_good_morning2)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctor: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtReminder: String? = MyApp.getInstance().resources.getString(R.string.lbl_reminder)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtVitals: String? = MyApp.getInstance().resources.getString(R.string.lbl_vitals)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtPrice: String? = MyApp.getInstance().resources.getString(R.string.lbl_sos)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtEarlyprotectio: String? =
      MyApp.getInstance().resources.getString(R.string.msg_early_protectio)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtDoctorOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_doctor)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeall: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtHealtharticle: String? =
      MyApp.getInstance().resources.getString(R.string.lbl_health_article)
  ,
  /**
   * TODO Replace with dynamic value
   */
  var txtSeeallOne: String? = MyApp.getInstance().resources.getString(R.string.lbl_see_all)

)
