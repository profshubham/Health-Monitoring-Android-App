package com.hmon.app.modules.physicalactivity.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import com.hmon.app.R
import com.hmon.app.appcomponents.base.BaseActivity
import com.hmon.app.databinding.ActivityPhysicalActivityBinding
import com.hmon.app.modules.physicalactivity.`data`.model.ListnameRowModel
import com.hmon.app.modules.physicalactivity.`data`.model.StaggeredellipsethirtyoneRowModel
import com.hmon.app.modules.physicalactivity.`data`.viewmodel.PhysicalVMVM
import kotlin.Int
import kotlin.String
import kotlin.Unit

class PhysicalActivityActivity :
    BaseActivity<ActivityPhysicalActivityBinding>(R.layout.activity_physical_activity) {
  private val viewModel: PhysicalVMVM by viewModels<PhysicalVMVM>()

  override fun onInitialized(): Unit {
    viewModel.navArguments = intent.extras?.getBundle("bundle")
    val staggeredellipsethirtyoneAdapter =
    StaggeredellipsethirtyoneAdapter(viewModel.staggeredellipsethirtyoneList.value?:mutableListOf())
    binding.recyclerStaggeredellipsethirtyone.adapter = staggeredellipsethirtyoneAdapter
    staggeredellipsethirtyoneAdapter.setOnItemClickListener(
    object : StaggeredellipsethirtyoneAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item :
      StaggeredellipsethirtyoneRowModel) {
        onClickRecyclerStaggeredellipsethirtyone(view, position, item)
      }
    }
    )
    viewModel.staggeredellipsethirtyoneList.observe(this) {
      staggeredellipsethirtyoneAdapter.updateData(it)
    }
    val listnameAdapter = ListnameAdapter(viewModel.listnameList.value?:mutableListOf())
    binding.recyclerListname.adapter = listnameAdapter
    listnameAdapter.setOnItemClickListener(
    object : ListnameAdapter.OnItemClickListener {
      override fun onItemClick(view:View, position:Int, item : ListnameRowModel) {
        onClickRecyclerListname(view, position, item)
      }
    }
    )
    viewModel.listnameList.observe(this) {
      listnameAdapter.updateData(it)
    }
    binding.physicalVMVM = viewModel
  }

  override fun setUpClicks(): Unit {
    binding.imageArrowleft.setOnClickListener {
      finish()
    }
    binding.imageArrowleftOne.setOnClickListener {
      finish()
    }
  }

  fun onClickRecyclerStaggeredellipsethirtyone(
    view: View,
    position: Int,
    item: StaggeredellipsethirtyoneRowModel
  ): Unit {
    when(view.id) {
    }
  }

  fun onClickRecyclerListname(
    view: View,
    position: Int,
    item: ListnameRowModel
  ): Unit {
    when(view.id) {
    }
  }

  companion object {
    const val TAG: String = "PHYSICAL_ACTIVITY_ACTIVITY"


    fun getIntent(context: Context, bundle: Bundle?): Intent {
      val destIntent = Intent(context, PhysicalActivityActivity::class.java)
      destIntent.putExtra("bundle", bundle)
      return destIntent
    }
  }
}
