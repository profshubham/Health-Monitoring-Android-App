package com.hmon.app.modules.sostwo.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.sostwo.`data`.model.SosTwoModel
import org.koin.core.KoinComponent

class SosTwoVM : ViewModel(), KoinComponent {
  val sosTwoModel: MutableLiveData<SosTwoModel> = MutableLiveData(SosTwoModel())

  var navArguments: Bundle? = null
}
