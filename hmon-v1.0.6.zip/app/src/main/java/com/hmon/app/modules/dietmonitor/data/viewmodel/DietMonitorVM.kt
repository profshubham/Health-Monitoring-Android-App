package com.hmon.app.modules.dietmonitor.`data`.viewmodel

import android.os.Bundle
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.hmon.app.modules.dietmonitor.`data`.model.DietMonitorModel
import com.hmon.app.modules.dietmonitor.`data`.model.ListeightRowModel
import com.hmon.app.modules.dietmonitor.`data`.model.ListtenRowModel
import kotlin.collections.MutableList
import org.koin.core.KoinComponent

class DietMonitorVM : ViewModel(), KoinComponent {
  val dietMonitorModel: MutableLiveData<DietMonitorModel> = MutableLiveData(DietMonitorModel())

  var navArguments: Bundle? = null

  val listeightList: MutableLiveData<MutableList<ListeightRowModel>> =
      MutableLiveData(mutableListOf())

  val listtenList: MutableLiveData<MutableList<ListtenRowModel>> = MutableLiveData(mutableListOf())
}
