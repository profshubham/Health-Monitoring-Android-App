package com.hmon.app.modules.dietmonitortwo.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.hmon.app.R
import com.hmon.app.databinding.RowListfourteenBinding
import com.hmon.app.modules.dietmonitortwo.`data`.model.ListfourteenRowModel
import kotlin.Int
import kotlin.collections.List

class ListfourteenAdapter(
  var list: List<ListfourteenRowModel>
) : RecyclerView.Adapter<ListfourteenAdapter.RowListfourteenVH>() {
  private var clickListener: OnItemClickListener? = null

  override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RowListfourteenVH {
    val view=LayoutInflater.from(parent.context).inflate(R.layout.row_listfourteen,parent,false)
    return RowListfourteenVH(view)
  }

  override fun onBindViewHolder(holder: RowListfourteenVH, position: Int) {
    val listfourteenRowModel = ListfourteenRowModel()
    // TODO uncomment following line after integration with data source
    // val listfourteenRowModel = list[position]
    holder.binding.listfourteenRowModel = listfourteenRowModel
  }

  override fun getItemCount(): Int = 2
  // TODO uncomment following line after integration with data source
  // return list.size

  public fun updateData(newData: List<ListfourteenRowModel>) {
    list = newData
    notifyDataSetChanged()
  }

  fun setOnItemClickListener(clickListener: OnItemClickListener) {
    this.clickListener = clickListener
  }

  interface OnItemClickListener {
    fun onItemClick(
      view: View,
      position: Int,
      item: ListfourteenRowModel
    ) {
    }
  }

  inner class RowListfourteenVH(
    view: View
  ) : RecyclerView.ViewHolder(view) {
    val binding: RowListfourteenBinding = RowListfourteenBinding.bind(itemView)
  }
}
